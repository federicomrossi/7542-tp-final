/*
 * Device.c
 *
 *  Created on: 24/03/2013
 *      Author: fiona
 */
#include "stdlib.h"
#include "stdio.h"
#include "string.h"
#include "Device.h"


Device* deviceCrear(int numero, const char* ip) {
	Device* aux = (Device*)malloc(sizeof(Device));
	aux->num = numero;
	aux->ip = (char*)malloc(strlen(ip)+1);
	strcpy(aux->ip, ip);
	return aux;
}

char* deviceGetIP(Device* unDevice) {
	return unDevice->ip;
}

int deviceComparar(Device* deviceA, Device* deviceB) {
	if ((deviceA->num) > (deviceB->num))return 1;
	if ((deviceA->num) < (deviceB->num))return -1;
	else return 0;
}

void deviceDestruir(Device* device) {
	free(device->ip);
	free(device);
}
