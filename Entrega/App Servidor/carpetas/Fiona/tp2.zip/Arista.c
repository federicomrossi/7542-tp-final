/*
 * Arista.c
 *
 *  Created on: 25/03/2013
 *      Author: fiona
 */


#include "stdlib.h"
#include "stdio.h"
#include "Lista.h"
#include "Vertice.h"
#include "Arista.h"


Arista* aristaCrear(Vertice* origen, Vertice* destino, int peso) {
	Arista* aux = (Arista*)malloc(sizeof(Arista));
	aux->origen = origen;
	aux->destino = destino;
	aux->peso = peso;
	return aux;
}
void aristaDestruir(Arista* arista) {
	free(arista);
}
