/*
 * Lista.c

 *
 *  Created on: 24/03/2013
 *      Author: fiona
 */

#include "stdio.h"
#include "Lista.h"
#include "stdlib.h"

//  Estructuras y Funciones auxiliares al objeto

typedef struct NodoListaEnlazada {
	void* dato;
	struct NodoListaEnlazada* sig;
} NodoLista;

NodoLista* nodoListaCrear(void* dato) {
	NodoLista* nodo = (NodoLista*)malloc(sizeof(NodoLista));
	nodo->dato = dato;
	nodo->sig = NULL;
	return nodo;
}

//  Estructuras y Funciones del objeto Lista

struct listaEnlazada {
	NodoLista* primero;
	NodoLista* ultimo;
	int cantidadNodos;
};

struct iteradorLista {
	NodoLista* anterior;
	NodoLista* actual;
};

//  Metodos de lista

Lista* listaCrear() {
	Lista* unalista = (Lista*)malloc(sizeof(Lista));
		if (!unalista) return 0;
		unalista->primero = NULL;
		unalista->ultimo = NULL;
		unalista->cantidadNodos = 0;
		return unalista;
}

void listaDestruir(Lista* lista, void destruirDato(void*)) {
	void* dato;

	while ((listaCantidadNodos(lista)) != 0) {
		listaBajaAlPrincipio(lista, &dato);
		if (destruirDato != NULL && dato != NULL) destruirDato(dato);
	}
	free(lista);
}

int listaCantidadNodos(const Lista* lista) {
	return lista->cantidadNodos;
}

int listaAltaAlFinal(Lista* lista, void* dato) {
	NodoLista* nodoNuevo;
	nodoNuevo = nodoListaCrear(dato);

	if (nodoNuevo == NULL) return 0;  //  imposible crear el prox nodo
	if ((lista->cantidadNodos) == 0) {
		lista->primero = nodoNuevo;
		lista->ultimo = nodoNuevo;
		lista->cantidadNodos = 1;
	} else {
		lista->ultimo->sig = nodoNuevo;
		lista->ultimo = nodoNuevo;
		lista->cantidadNodos +=1;
	}
		return 1;
}
int listaInsertarPrimero(Lista* lista, void* dato) {
	NodoLista* nuevoNodo;
	nuevoNodo = nodoListaCrear(dato);
	if (nuevoNodo == NULL) return 0;
	nuevoNodo->sig = lista->primero;
	lista->primero = nuevoNodo;

	if (lista->ultimo == NULL) lista->ultimo = nuevoNodo;
	lista->cantidadNodos++;
	return 1;
}

int listaVerPrimero(const Lista* lista, void** dato) {
	if (listaCantidadNodos(lista)) {
		*dato = lista->primero->dato;
		return 1;
	} else {
		return 0;
	}
}

int listaBajaAlPrincipio(Lista* lista, void** dato) {
	if (!listaVerPrimero(lista, dato)) return 0;
	NodoLista* aux = lista->primero;
	lista->primero = aux->sig;
	if (lista->primero == NULL) lista->ultimo = NULL;
	free(aux);
	lista->cantidadNodos--;
	return 1;
}

int listaGetCantidadNodos(Lista* lista) {
	return lista->cantidadNodos;
}

//  metodos del iterador

IteradorLista* iteradorListaCrear(const Lista* lista) {
	IteradorLista* iter = (IteradorLista*)malloc(sizeof(IteradorLista));
	if (!iter) return 0;
	iter->anterior = lista->primero;
	iter->actual = lista->primero;
	return iter;
}

int iteradorListaAvanzar(IteradorLista* iter) {
	if (iter->actual == NULL) return 0;
	if (iter->actual->sig == NULL) {
		iter->actual = NULL;
		return 0;  //  llegue al final
	}
	iter->anterior = iter->actual;
	iter->actual = iter->actual->sig;
	return 1;
}

int iteradorListaVerActual(const IteradorLista* iter, void** dato) {
	if (iter->actual != NULL) {
		*dato = iter->actual->dato;
		return 1;
	} else {
		return 0;
	}
}
void iteradorListaDestruir(IteradorLista* iter) {
	free(iter);
}

//  metodos compartidos

int listaAltaOrdenada(Lista* lista, void* nuevoDato, 
			int funcioncomp(void*, void*)) {
	if (lista->cantidadNodos == 0) {
		return listaAltaAlFinal(lista, nuevoDato);
	}
	if ((lista->cantidadNodos) != 0) {
		NodoLista* nodoNuevo;
		nodoNuevo = nodoListaCrear(nuevoDato);

		IteradorLista* iter = iteradorListaCrear(lista);
		void* datoActual;
		int comparar;

		while ((iter->actual) != NULL) {
			iteradorListaVerActual(iter, &datoActual);
			comparar = funcioncomp(nuevoDato, datoActual);
			if (comparar == 1) {  // nuevoDato mayor que el actual -> avanzo
				iteradorListaAvanzar(iter);
				} else {
					iter->anterior->sig = nodoNuevo;
					nodoNuevo->sig = iter->actual;
					lista->cantidadNodos++;
					iteradorListaDestruir(iter);
					return 1;
					}
				}
		free(nodoNuevo);
		listaAltaAlFinal(lista, nuevoDato);
		iteradorListaDestruir(iter);
		}

	return 1;
}
