/*
 * Vertice.h
 *
 *  Created on: 25/03/2013
 *      Author: fiona
 */

#ifndef VERTICE_H_
#define VERTICE_H_


typedef struct VerticeGrafo Vertice;

Vertice* verticeCrear(void* info);
void* verticeGetDato(Vertice* vertice);
int verticeAgregarArista(Vertice* vertice, Vertice* destino, int peso);
int verticeComparar(Vertice* verticeA, Vertice* verticeB);
void verticeSetPeso(Vertice* unVertice, int valor);
int verticeGetPeso(Vertice* unVertice);
Lista* verticeGetAristas(Vertice* unVertice);
void verticeSetPrevio(Vertice* unVertice, Vertice* anterior);
Vertice* verticeGetPrevio(Vertice* unVertice);
void verticeDestruir(Vertice* vertice);

#endif /* VERTICE_H_ */
