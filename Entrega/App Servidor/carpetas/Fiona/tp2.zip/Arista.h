/*
 * Arista.h
 *
 *  Created on: 25/03/2013
 *      Author: fiona
 */

#ifndef ARISTA_H_
#define ARISTA_H_



typedef struct AristaGrafo {
	Vertice* origen;
	Vertice* destino;
	int peso;
}Arista;

Arista* aristaCrear(Vertice* origen, Vertice* destino, int peso);
void aristaDestruir(Arista* arista);

#endif /* ARISTA_H_ */
