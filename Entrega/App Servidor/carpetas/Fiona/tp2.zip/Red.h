/*
 * Red.h
 *
 *  Created on: 25/03/2013
 *      Author: fiona
 */

#ifndef RED_H_
#define RED_H_

typedef struct RedEquipos Red;

Red* redCrear();
int redAgregarDevice(Red* red, int num, const char* ip);
int redAgregarHost(Red* red, const char* nom, const char* ip, int numero);
int redAgregarConexion(Red* red, int ppio, int final, int peso);
int redCargarGrafo(Red* red);
void redCaminoMinimoDeConexion(Red* red);
void redDestruir(Red* red);

#endif /* RED_H_ */
