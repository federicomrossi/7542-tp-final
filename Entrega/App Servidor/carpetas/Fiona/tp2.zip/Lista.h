/*
 * Lista.h
 *
 *  Created on: 23/03/2013
 *      Author: fiona
 */

#ifndef LISTA_H_
#define LISTA_H_

#include <stdint.h>

#include <stddef.h>

//  Definicion de los Tipos de Datos

typedef struct listaEnlazada Lista;
typedef struct iteradorLista IteradorLista;

// Primitivas de la Lista

Lista* listaCrear();
void listaDestruir(Lista* lista, void destruirDato(void*));
int listaCantidadNodos(const Lista* lista);
int listaAltaAlFinal(Lista* lista, void* dato);
int listaInsertarPrimero(Lista* lista, void* dato);
int listaBajaAlPrincipio(Lista* lista, void** dato);
IteradorLista* iteradorListaCrear(const Lista* lista);
int iteradorListaAvanzar(IteradorLista* iter);
int iteradorListaVerActual(const IteradorLista* iter, void** dato);
int iteradorListaFinal(const IteradorLista* iter);
int listaGetCantidadNodos(Lista* lista);
void iteradorListaDestruir(IteradorLista* iter);

// Metodos compartidos

int listaAltaOrdenada(Lista* lista, void* nuevoDato, 
		      int funcioncomp(void*, void*));

#endif /* LISTA_H_ */
