/*
 * ProcesadorDeCarga.c
 *
 *  Created on: 28/03/2013
 *      Author: fiona
 */
#include "stdlib.h"
#include "stdio.h"
#include "string.h"
#include "Red.h"
#include "Host.h"
#include "Device.h"

#define LONG_BUFFER 50

int EncontrarSeparador(const char *cad, int inicio, const char* separador) {
	int fin = inicio;
	int result = 1;

	while (result != 0) {
	result = strncmp(&(cad[fin]), separador, 1);
		if (result != 0)
			result = strncmp(&(cad[fin]), "\n", 1);
	fin++;
	}
	fin -=2;  //  queda adelantado
	return fin;
}

void ProcesarHost(Red* red, char* cadena, int* flagDeCarga) {
	char aux[50];
	int auxDevice;
	int fin= 0;
	int inicio = 0;
	const char *separador = ",";
	char auxNombre[LONG_BUFFER];
	char auxIP[LONG_BUFFER];

	if (cadena[0] == '[') {
    	*flagDeCarga = 2;
    	return;
  	}
	fin = EncontrarSeparador(cadena, inicio, separador);
	memcpy(auxNombre, cadena, fin - inicio +1);
	auxNombre[fin - inicio +1] = '\0';

	inicio = fin +2;
	fin = EncontrarSeparador(cadena, inicio, separador);
	memcpy(auxIP, cadena+inicio, fin - inicio +1);
	auxIP[fin - inicio +1] = '\0';


	inicio = fin +2;
	fin = EncontrarSeparador(cadena, inicio, separador);
	memcpy(aux, cadena +inicio, fin - inicio +1);
	aux[fin - inicio +1] = '\0';
	auxDevice = atoi(aux);

	redAgregarHost(red, auxNombre, auxIP, auxDevice);
}

void ProcesarDevice(Red* red, const char* cadena, int* flagDeCarga) {
	char auxNumero[LONG_BUFFER];
	char auxIP[LONG_BUFFER];
	int fin= 0;
	int inicio = 0;
	char separador = ',';
	int numero = 0;

	if (cadena[0] == '[') {
    	*flagDeCarga = 3;
    	return;
	}
	fin = EncontrarSeparador(cadena, inicio, &separador);
	memcpy(auxNumero, cadena, fin - inicio +1);
	auxNumero[fin - inicio +1] = '\0';
	numero = atoi(auxNumero);

	inicio = fin +2;
	fin = EncontrarSeparador(cadena, inicio, &separador);
	memcpy(auxIP, cadena+inicio, fin - inicio +1);
	auxIP[fin - inicio +1] = '\0';
	redAgregarDevice(red, numero, auxIP);
}

void ProcesarRoute(Red* red, char* cadena) {
	char aux[LONG_BUFFER];
	int fin= 0;
	int inicio = 0;
	const char *separador1 = "-";
	int origen;
	int destino;
	int peso;
	const char *separador2 = ",";

	fin = EncontrarSeparador(cadena, inicio, separador1);
	memcpy(aux, cadena, fin - inicio +1);
	aux[fin - inicio +1] = '\0';
	origen = atoi(aux);

	inicio = fin +3;
	fin = EncontrarSeparador(cadena, inicio, separador2);
	memcpy(aux, cadena+inicio, fin - inicio +1);
	aux[fin - inicio +1] = '\0';
	destino = atoi(aux);

	inicio = fin +2;
	fin = EncontrarSeparador(cadena, inicio, separador2);
	memcpy(aux, cadena+inicio, fin - inicio +1);
	aux[fin - inicio + 1] = '\0';
	peso = atoi(aux);
	redAgregarConexion(red, origen, destino, peso);
}

int ProcesarArchivo(FILE* entrada, Red* red) {
	char buffer[LONG_BUFFER];
	int result;
	int flagDeCarga;
	char* leidos;

	leidos = fgets(buffer, LONG_BUFFER, entrada);
	const char* cHost = "[host]";
	result = strncmp(&(buffer[0]), cHost, 6);
	if (result == 0) {
		flagDeCarga = 1;
	}
	while ((flagDeCarga == 1) && ((leidos != NULL))) {
		leidos = fgets(buffer, LONG_BUFFER, entrada);
		ProcesarHost(red, buffer, &flagDeCarga);
	}
	while ((flagDeCarga == 2) && (leidos != NULL)) {
		leidos = fgets(buffer, LONG_BUFFER, entrada);
		ProcesarDevice(red, buffer, &flagDeCarga);
	}
	redCargarGrafo(red);

	while ((leidos != NULL)) {
		leidos = fgets(buffer, LONG_BUFFER, entrada);
		ProcesarRoute(red, buffer);
	}
	return 0;
}
