/*
 * Grafo.h
 *
 *  Created on: 25/03/2013
 *      Author: fiona
 */

#ifndef GRAFO_H_
#define GRAFO_H_

typedef struct Digrafo Grafo;


Grafo* grafoCrear();
int grafoAgregarVertice(Grafo* grafo, void* dato);
int grafoAgregarArista(Grafo* unGrafo, void* desde, void* hasta, int peso);
Lista* grafoCaminoMinimo(Grafo* unGrafo, void* origen, void* destino);
void grafoDestruir(Grafo* unGrafo);


#endif /* GRAFO_H_ */
