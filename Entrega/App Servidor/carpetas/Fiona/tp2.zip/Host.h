/*
 * Host.h
 *
 *  Created on: 25/03/2013
 *      Author: fiona
 */

#ifndef HOST_H_
#define HOST_H_

typedef struct host Host;

Host* hostCrear(const char* nombre, const char* IP, int numeroDevice);
int hostGetNumeroDevice(Host* unHost);
char* hostGetNombre(Host* unHost);
char* hostGetIp(Host* unHost);
void hostDestruir(Host* unHost);

#endif /* HOST_H_ */
