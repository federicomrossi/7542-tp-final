/*
 * main.c
 *
 *  Created on: 26/03/2013
 *      Author: fiona
 */
#include "stdio.h"
#include "stdlib.h"
#include "Red.h"
#include "Lista.h"
#include "Device.h"
#include "ProcesadorDeCarga.h"
#include "Vertice.h"



int main(int argc, char* argv[]) {
	FILE *archivoEntrada;
	if (argc == 2) {
		char *pathEntrada = argv[1];
		archivoEntrada = fopen(pathEntrada, "rb");
		if (archivoEntrada == NULL) {
			return 1;
		}
	} else {
		archivoEntrada = stdin;
	}
	
	Red* red;
	red = redCrear();

	if (archivoEntrada == NULL) {
		return 1;
	}

	int re = ProcesarArchivo(archivoEntrada, red);
	redCaminoMinimoDeConexion(red);
	redDestruir(red);
	fclose(archivoEntrada);

return re;
}
