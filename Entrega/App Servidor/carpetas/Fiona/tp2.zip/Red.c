/*
 * Red.c
 *
 *  Created on: 25/03/2013
 *      Author: fiona
 */

#include "stdio.h"
#include "stdlib.h"
#include "Red.h"
#include "Lista.h"
#include "Device.h"
#include "Host.h"
#include "Grafo.h"


struct RedEquipos {
	Grafo* mapaDeRed;
	Lista* devices;
	Lista* hosts;
};

Red* redCrear() {
	Red* aux = (Red*)malloc(sizeof(Red));
	aux->devices = listaCrear();
	aux->hosts = listaCrear();
	aux->mapaDeRed = grafoCrear();
	return aux;
}

Device* redGetDevice(Red* red, int numero) {
	void* dato;
	IteradorLista* it = iteradorListaCrear(red->devices);
	while(iteradorListaVerActual(it, &dato) != 0) {
		if ((((Device*)dato)->num) == numero) {
			iteradorListaDestruir(it);
			return (Device*)dato;
		}
		iteradorListaAvanzar(it);
	}
	iteradorListaDestruir(it);
	return NULL;
}

int redAgregarDevice(Red* red, int num, const char* ip) {
	Device* unDevice = deviceCrear(num, ip);
	if (unDevice == NULL) return 0;
	
	int bol = listaAltaOrdenada(red->devices, unDevice, 
				   (int(*)(void*, void*))deviceComparar);
	return bol;
}

int redCargarGrafo(Red* red) {
	IteradorLista* it = iteradorListaCrear(red->devices);
	void* dato;
	while(iteradorListaVerActual(it, (void*)&dato) != 0) {
		grafoAgregarVertice(red->mapaDeRed, dato);
		iteradorListaAvanzar(it);
	}
	iteradorListaDestruir(it);
	return 1;
}

int redAgregarHost(Red* red, const char* nom, const char* ip, int numero) {
	Host* nuevoHost = hostCrear(nom, ip, numero);
	if (nuevoHost == NULL) return 0;
	int bol = listaAltaAlFinal(red->hosts, nuevoHost);
	if (bol == 0) return 0;
	return 1;
}

int redAgregarConexion(Red* red, int ppio, int final, int peso) {
	Device* datoInicio;
	Device* datoFin;
	datoInicio = redGetDevice(red, ppio);
	datoFin = redGetDevice(red, final);
	return grafoAgregarArista(red->mapaDeRed, datoInicio, datoFin, peso);
}

void redImprimir(Lista* resultado, Host* hostOrigen, Host* host) {
	void* dato;
	char* hOrigen = hostGetNombre(hostOrigen);
	char* hDestino = hostGetNombre(host);
	int contador = 1;

	printf("[route_path:");
	printf("%s", hOrigen);
	printf("->");
	printf("%s]\n", hDestino);
	printf("%d", contador);
	printf(":");
	hOrigen = hostGetIp(hostOrigen);
	printf("%s\n", hOrigen);
	contador++;
	IteradorLista* it = iteradorListaCrear(resultado);

	while (iteradorListaVerActual(it, &dato) != 0) {
		printf("%d", contador);
		printf(":");
		printf("%s\n", (deviceGetIP((Device*)dato)));
		contador++;
		iteradorListaAvanzar(it);
	}
	printf("%d", contador);
	printf(":");
	hDestino = hostGetIp(host);
	printf("%s\n", hDestino);

	iteradorListaDestruir(it);
	listaDestruir(resultado, NULL);
}

void redCaminoMinimoDeConexion(Red* red) {
	Host* host;
	Device* dOrigen;
	Device* dDestino;
	IteradorLista* it = iteradorListaCrear(red->hosts);
	iteradorListaVerActual(it, (void**)&host);
	iteradorListaAvanzar(it);
	Lista* resultado;

	int origen = hostGetNumeroDevice((host));
	Host* hostOrigen = host;
	dOrigen = redGetDevice(red, origen);

	while(iteradorListaVerActual(it, (void**)&host) != 0) {
		int destino = hostGetNumeroDevice(host);
		dDestino = redGetDevice(red, destino);
		resultado = grafoCaminoMinimo(red->mapaDeRed, (void*)dOrigen, 
					     (void*)dDestino);
		redImprimir(resultado, hostOrigen, host);
		iteradorListaAvanzar(it);
	}
	iteradorListaDestruir(it);
}

void redDestruir(Red* red) {
	grafoDestruir(red->mapaDeRed);
	listaDestruir(red->hosts, (void (*)(void *))hostDestruir);
	listaDestruir(red->devices, (void (*)(void *))deviceDestruir);
	free(red);
} 
