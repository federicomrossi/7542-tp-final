/*
 * Vertice.c
 *
 *  Created on: 25/03/2013
 *      Author: fiona
 */
#include "stdlib.h"
#include "stdio.h"
#include "Lista.h"
#include "Vertice.h"
#include "Arista.h"


struct VerticeGrafo {
	void* dato;
	Lista* aristas;
	int pesoDijkstra;
	Vertice* previo;  //  Permite recuperar el camino minimo
};

Vertice* verticeCrear(void* dato) {
	Vertice* aux = (Vertice*)malloc(sizeof(Vertice));
	aux->dato = dato;
	aux->aristas = listaCrear();
	aux->previo = NULL;
	return aux;
}

void* verticeGetDato(Vertice* vertice) {
	return vertice->dato;
}

int verticeAgregarArista(Vertice* vertice, Vertice* destino, int peso) {
	Arista* nueva = aristaCrear(vertice, destino, peso);
	return listaAltaAlFinal(vertice->aristas, nueva);
}

int verticeComparar(Vertice* verticeA, Vertice* verticeB) {
	if ((verticeA->pesoDijkstra) >= (verticeB->pesoDijkstra))return 1;
	if ((verticeA->pesoDijkstra) < (verticeB->pesoDijkstra))return -1;
	else return 0;
}

Lista* verticeGetAristas(Vertice* unVertice) {
	return unVertice->aristas;
}

void verticeSetPeso(Vertice* unVertice, int valor) {
	unVertice->pesoDijkstra = valor;
}

int verticeGetPeso(Vertice* unVertice) {
	return unVertice->pesoDijkstra;
}
void verticeSetPrevio(Vertice* unVertice, Vertice* anterior) {
	unVertice->previo = anterior;
}
Vertice* verticeGetPrevio(Vertice* unVertice) {
	return unVertice->previo;
}
void verticeDestruir(Vertice* vertice) {
	listaDestruir(vertice->aristas, (void (*)(void *)) aristaDestruir );
	free(vertice);
}
