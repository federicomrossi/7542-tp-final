/*
 * Grafo.c
 *
 *  Created on: 25/03/2013
 *      Author: fiona
 */

#include "Lista.h"
#include "stdlib.h"
#include "stdio.h"
#include "Vertice.h"
#include "Arista.h"
#include "Grafo.h"

const int INF = 100000;

struct Digrafo {
	Lista* Vertices;
};

Grafo* grafoCrear() {
	Grafo* aux = (Grafo*)malloc(sizeof(Grafo));
	aux->Vertices = listaCrear();
	return aux;
}

int grafoAgregarVertice(Grafo* unGrafo, void* dato) {
	Vertice* nuevoVertice = verticeCrear(dato);

	if (nuevoVertice == NULL) return 0;
	int bol = listaAltaAlFinal(unGrafo->Vertices, nuevoVertice);
		if (bol == 0) return 0;
	return 1;
}

Vertice* grafoBuscarVertice(Grafo* unGrafo, void* datoBuscado) {
	Vertice* verticeBuscado = NULL;
	int bol = 0;

	IteradorLista* it = iteradorListaCrear(unGrafo->Vertices);

	bol = iteradorListaVerActual(it, (void**)&verticeBuscado);
	//  mientras la direccion del dato del vertice sea distinta a
	//  la direccion del buscado
	while ((bol == 1) && (datoBuscado != verticeGetDato(verticeBuscado))) {  
		bol = iteradorListaAvanzar(it);
		int finDeLista = iteradorListaVerActual(it, (void**)&verticeBuscado);
		if (finDeLista == 0) return NULL;
	}
	iteradorListaDestruir(it);
	return verticeBuscado;
}

int grafoAgregarArista(Grafo* unGrafo, void* desde, void* hasta, int peso) {
	Vertice *origen = grafoBuscarVertice(unGrafo, desde);
	Vertice *destino = grafoBuscarVertice(unGrafo, hasta);
	if ( origen == NULL || destino == NULL) return 0;
	return verticeAgregarArista(origen, destino, peso);
}
int grafoGetCantidadVertices(Grafo* unGrafo) {
	return listaGetCantidadNodos(unGrafo->Vertices);
}

//  Métodos utilizados para la resulución del problema de caminos mínimos
void grafoSetPesos(Grafo* unGrafo) {
	void* dato;
	IteradorLista* it = iteradorListaCrear(unGrafo->Vertices);

	iteradorListaVerActual(it, &dato);
	verticeSetPeso((Vertice*)dato, 0);
	verticeSetPrevio((Vertice*)dato, NULL);
	iteradorListaAvanzar(it);

	while (iteradorListaVerActual(it, &dato) != 0) {
		verticeSetPeso((Vertice*)dato, INF);
		verticeSetPrevio((Vertice*)dato, NULL);
		iteradorListaAvanzar(it);
	}
	iteradorListaDestruir(it);
}

void grafoDijkstra(Grafo* unGrafo, void* datoOrigen ) {
	Vertice* dato;
	Arista* arista;
	Lista* listaOrdenada = listaCrear();
	Vertice* buscado = grafoBuscarVertice(unGrafo, datoOrigen);

	listaAltaOrdenada(listaOrdenada, buscado, 
			 (int(*)(void*, void*))verticeComparar);

	while(listaCantidadNodos(listaOrdenada) != 0) {
		IteradorLista* it = iteradorListaCrear(listaOrdenada);
		iteradorListaVerActual(it, (void**)&dato);
		Lista* auxAristas = verticeGetAristas(dato);
		IteradorLista* itAristas = iteradorListaCrear(auxAristas);

		while (iteradorListaVerActual(itAristas, (void**)&arista) != 0) {
			int pOrigen = verticeGetPeso(arista->origen);
			int pDestino = verticeGetPeso(arista->destino);

			pOrigen += (arista)->peso;
			if (pOrigen < pDestino) {
				verticeSetPeso(((Arista*)arista)->destino, pOrigen);
				verticeSetPrevio(arista->destino, arista->origen);
				listaAltaOrdenada(listaOrdenada, arista->destino, 
						 (int(*)(void*, void*))verticeComparar);
			}
			iteradorListaAvanzar(itAristas);
		}
		listaBajaAlPrincipio(listaOrdenada, (void**)&dato);
		iteradorListaDestruir(it);
		iteradorListaDestruir(itAristas);
	}
	listaDestruir(listaOrdenada, NULL);
}

Lista* crearListaResultado(Grafo* unGrafo, Vertice* destino) {
	Lista* resultado = listaCrear();
	listaInsertarPrimero(resultado, verticeGetDato(destino));

		while(verticeGetPrevio(destino) != NULL) {
			destino = verticeGetPrevio(destino);
			listaInsertarPrimero(resultado, verticeGetDato(destino));
		}
	return resultado;
}

Lista* grafoCaminoMinimo(Grafo* unGrafo, void* origen, void* destino) {
	grafoSetPesos(unGrafo);
	grafoDijkstra(unGrafo, origen);
	Vertice* Vdestino = grafoBuscarVertice(unGrafo, destino);
	Lista* resultado = crearListaResultado(unGrafo, Vdestino);

	return resultado;
}

void grafoDestruir(Grafo* unGrafo) {
	listaDestruir(unGrafo->Vertices, (void (*)(void *))verticeDestruir);
	free(unGrafo);
}
