/*
 * ProcesadorDeCarga.h
 *
 *  Created on: 28/03/2013
 *      Author: fiona
 */

#ifndef PROCESADORDECARGA_H_
#define PROCESADORDECARGA_H_

int ProcesarArchivo(FILE* entrada, Red* red);

#endif /* PROCESADORDECARGA_H_ */
