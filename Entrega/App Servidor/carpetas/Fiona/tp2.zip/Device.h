/*
 * Device.h
 *
 *  Created on: 24/03/2013
 *      Author: fiona
 */

#ifndef DEVICE_H_
#define DEVICE_H_

typedef struct device {
		int num;
		char* ip;
	}Device;

Device* deviceCrear(int numero, const char* ip);
char* deviceGetIP(Device* unDevice);
int deviceComparar(Device* deviceA, Device* deviceB);
void deviceDestruir(Device* device);

#endif /* DEVICE_H_ */
