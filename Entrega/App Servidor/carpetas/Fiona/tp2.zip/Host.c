/*
 * Host.c
 *
 *  Created on: 25/03/2013
 *      Author: fiona
 */

#include "string.h"
#include "stdlib.h"
#include "stdio.h"
#include "Host.h"

struct host {
	char* nombre;
	char* IP;
	int NumeroDevice;
};

Host* hostCrear(const char* nombre, const char* IP, int numero) {
	Host* nuevoHost = (Host*)malloc(sizeof(Host));

	nuevoHost->nombre = (char*)malloc(strlen(nombre)+1);
	strcpy(nuevoHost->nombre, nombre);
	nuevoHost->IP = (char*)malloc(strlen(IP)+1);
	strcpy(nuevoHost->IP, IP);
	nuevoHost->NumeroDevice = numero;

	return nuevoHost;
}

char* hostGetIp(Host* unHost) {
	return unHost->IP;
}

char* hostGetNombre(Host* unHost) {
	return unHost->nombre;
}
int hostGetNumeroDevice(Host* unHost) {
	return unHost->NumeroDevice;
}
void hostDestruir(Host* unHost) {
	free(unHost->nombre);
	free(unHost->IP);
	free(unHost);
}
